/* see bouncycastle_license.txt */

package com.lowagie.bc.asn1;

/**
 * the parent class for this will eventually disappear. Use this one!
 */
public class ASN1EncodableVector
    extends DEREncodableVector
{
}
